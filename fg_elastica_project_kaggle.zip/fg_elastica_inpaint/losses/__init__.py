from .inpainting import InpaintingLoss
